import { Routes } from '@angular/router';

import { Login } from './pages/login/login';
import { Dashboard } from './pages/Dashboard/dashboard';
import { Alerts } from './pages/alerts/alerts';
import { Downtime } from './pages/downtime/downtime';
import { Reports } from './pages/Report/reports';
import { UserManagement } from './pages/user-management/user-management';
import { Employees } from './pages/employees/employees';

import { authGuard } from './auth.guard';

export const routes: Routes = [

  // 🔓 Login page
  { path: '', component: Login },

  // 🖥️ Dashboard (all roles)
  {
    path: 'dashboard',
    component: Dashboard,
    canActivate: [authGuard],
    data: { roles: ['Admin', 'Supervisor', 'Operator', 'Maintenance'] }
  },

  // 🚨 Alerts
  {
    path: 'alerts',
    component: Alerts,
    canActivate: [authGuard],
    data: { roles: ['Admin', 'Supervisor', 'Maintenance'] }
  },

  // ⏱️ Downtime
  {
    path: 'downtime',
    component: Downtime,
    canActivate: [authGuard],
    data: { roles: ['Admin', 'Maintenance'] }
  },

  // 📈 Reports
  {
    path: 'reports',
    component: Reports,
    canActivate: [authGuard],
    data: { roles: ['Admin', 'Supervisor'] }
  },

  // 👥 User Management
  {
    path: 'users',
    component: UserManagement,
    canActivate: [authGuard],
    data: { roles: ['Admin'] }
  },

  // 👨‍💼 Employees
  {
    path: 'employees',
    component: Employees,
    canActivate: [authGuard],
    data: { roles: ['Admin', 'Supervisor'] }
  }

];