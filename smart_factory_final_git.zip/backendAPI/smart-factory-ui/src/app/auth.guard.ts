import { CanActivateFn } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const role = localStorage.getItem('role');
  const allowedRoles = route.data?.['roles'];

  if (allowedRoles && !allowedRoles.includes(role)) {
    alert('Access Denied');
    return false;
  }

  return true;
};