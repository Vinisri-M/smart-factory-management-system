import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [NgFor, NgIf, FormsModule],
  templateUrl: './user-management.html',
  styleUrl: './user-management.css'
})
export class UserManagement implements OnInit {

  selectedRole = 'All';
  roles = ['All', 'Admin', 'Supervisor', 'Operator', 'Maintenance'];

  users: any[] = [];

  showForm = false;
  editIndex: number | null = null;

  formUser = {
    empId: '',
    name: '',
    email: '',
    role: 'Operator',
    status: 'Active',
    lastLogin: 'Not logged-in'
  };

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private zone: NgZone
  ) {}

  ngOnInit() {
    this.selectedRole = 'All';
    this.fetchUsers();
  }

  getHeaders() {
    const token = localStorage.getItem('token');

    return new HttpHeaders().set(
      'Authorization',
      `Bearer ${token}`
    );
  }

  fetchUsers() {
    this.http.get<any[]>(
      'http://localhost:5028/api/Users',
      { headers: this.getHeaders() }
    ).subscribe({
      next: (data) => {
        this.zone.run(() => {
          this.users = data;
          this.selectedRole = 'All';
          this.cdr.detectChanges();
        });

        console.log('Users loaded:', this.users);
      },
      error: (err) => {
        console.error('Error fetching users', err);
      }
    });
  }

  get filteredUsers() {
    if (this.selectedRole === 'All') {
      return this.users;
    }

    return this.users.filter(
      user => user.role === this.selectedRole
    );
  }

  openAddForm() {
    this.showForm = true;
    this.editIndex = null;

    this.formUser = {
      empId: '',
      name: '',
      email: '',
      role: 'Operator',
      status: 'Active',
      lastLogin: ''
    };
  }

  editUser(user: any) {
    this.showForm = true;
    this.editIndex = this.users.indexOf(user);

    this.formUser = {
      empId: user.empId,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      lastLogin: user.lastLogin
    };
  }

  saveUser() {
    if (this.editIndex === null) {
      this.http.post<any>(
        'http://localhost:5028/api/Users',
        this.formUser,
        { headers: this.getHeaders() }
      ).subscribe({
        next: () => {
          this.fetchUsers();
          this.cancelForm();
        },
        error: (err) => {
          console.error('Error adding user', err);
        }
      });
    } else {
      const userId = this.users[this.editIndex].id;

      this.http.put<any>(
        `http://localhost:5028/api/Users/${userId}`,
        this.formUser,
        { headers: this.getHeaders() }
      ).subscribe({
        next: () => {
          this.fetchUsers();
          this.cancelForm();
        },
        error: (err) => {
          console.error('Error updating user', err);
        }
      });
    }
  }

  deleteUser(user: any) {
    const confirmDelete = confirm(
      `Are you sure you want to delete ${user.name}?`
    );

    if (!confirmDelete) {
      return;
    }

    this.http.delete(
      `http://localhost:5028/api/Users/${user.id}`,
      { headers: this.getHeaders() }
    ).subscribe({
      next: () => {
        this.fetchUsers();
      },
      error: (err) => {
        console.error('Error deleting user', err);
      }
    });
  }

  cancelForm() {
    this.showForm = false;
    this.editIndex = null;

    this.formUser = {
      empId: '',
      name: '',
      email: '',
      role: 'Operator',
      status: 'Active',
      lastLogin: ''
    };
  }
}