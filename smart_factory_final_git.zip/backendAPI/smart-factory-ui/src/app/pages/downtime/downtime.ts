import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-downtime',
  standalone: true,
  imports: [NgFor, NgIf, FormsModule],
  templateUrl: './downtime.html',
  styleUrl: './downtime.css',
})

export class Downtime implements OnInit {

  machineFilter = 'All';
  reasonFilter = 'All';

  fromDate = '';
  toDate = '';

  // API DATA
  downtimeList: any[] = [];

  constructor(private http: HttpClient) {}

  // ================= INIT =================

  ngOnInit(): void {
    this.fetchDowntime();
  }

  // ================= API CALL =================

  fetchDowntime() {

    const token = localStorage.getItem('token');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any[]>(
      'http://localhost:5028/api/Downtime',
      { headers }
    ).subscribe({

      next: (data) => {
        this.downtimeList = data;
      },

      error: (err) => {
        console.error('Error fetching downtime data', err);
      }

    });
  }

  // ================= FILTER OPTIONS =================

  machines = [
    'All',
    'Milling Machine B2','Inspection Conveyor H8','Cooling System O15','Palletizer V22'
  ];

  reasons = [
    'All',
    'Telemetry anomaly',
    'Power Issue',
    'Maintenance work',
    'Network Issue'
  ];

  // ================= DATE VALIDATION =================

  get dateError() {

    if (this.fromDate && !this.toDate) {
      return 'Please select To date';
    }

    if (!this.fromDate && this.toDate) {
      return 'Please select From date';
    }

    if (
      this.fromDate &&
      this.toDate &&
      this.fromDate > this.toDate
    ) {
      return 'From date cannot be greater than To date';
    }

    return '';
  }

  // ================= FILTER DATA =================

  get filteredDowntime() {

    if (this.dateError) {
      return [];
    }

    return this.downtimeList.filter(item => {

      const machineMatch =
        this.machineFilter === 'All' ||
        item.machine === this.machineFilter;

      const reasonMatch =
        this.reasonFilter === 'All' ||
        item.reason === this.reasonFilter;

      const dateMatch =

        (!this.fromDate && !this.toDate) ||

        (
          this.fromDate &&
          this.toDate &&
          item.date >= this.fromDate &&
          item.date <= this.toDate
        );

      return (
        machineMatch &&
        reasonMatch &&
        dateMatch
      );

    });

  }

  // ================= CLEAR FILTERS =================

  clearFilters() {

    this.machineFilter = 'All';
    this.reasonFilter = 'All';

    this.fromDate = '';
    this.toDate = '';

  }

}