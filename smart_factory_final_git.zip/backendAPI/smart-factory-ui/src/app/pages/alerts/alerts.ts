import { Component, OnInit } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-alerts',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, FormsModule],
  templateUrl: './alerts.html',
  styleUrl: './alerts.css'
})

export class Alerts implements OnInit {

  severityFilter = 'All';
  machineFilter = 'All';
  statusFilter = 'All';

  fromDate = '';
  toDate = '';

  role = localStorage.getItem('role');

  // API DATA
  alerts: any[] = [];

  constructor(private http: HttpClient) {}

  // ================= INIT =================

  ngOnInit(): void {
    this.fetchAlerts();
  }

  // ================= GET ALERTS =================

  fetchAlerts() {

    const token = localStorage.getItem('token');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any[]>(
      'http://localhost:5028/api/Alerts',
      { headers }
    ).subscribe({

      next: (data) => {
        this.alerts = data;
      },

      error: (err) => {
        console.error('Error fetching alerts', err);
      }

    });
  }

  // ================= FILTER OPTIONS =================

  severities = ['All', 'High', 'Medium', 'Low'];

  machines = [
    'All',
    'Robotic Arm C3','Press Machine E5','Welding Station F6','Packaging Unit I9','Assembly Robot K11','Conveyor Lift L12'
  ];

  statuses = ['All', 'Open', 'Closed'];

  // ================= DATE VALIDATION =================

  get dateError() {

    if (this.fromDate && !this.toDate) {
      return 'Please select To date';
    }

    if (!this.fromDate && this.toDate) {
      return 'Please select From date';
    }

    if (
      this.fromDate &&
      this.toDate &&
      this.fromDate > this.toDate
    ) {
      return 'From date cannot be greater than To date';
    }

    return '';
  }

  // ================= FILTER ALERTS =================

  get filteredAlerts() {

    if (this.dateError) {
      return [];
    }

    return this.alerts.filter(alert => {

      const severityMatch =
        this.severityFilter === 'All' ||
        alert.severity === this.severityFilter;

      const machineMatch =
        this.machineFilter === 'All' ||
        alert.machine === this.machineFilter;

      const statusMatch =
        this.statusFilter === 'All' ||
        alert.status === this.statusFilter;

      const dateMatch =
        (!this.fromDate && !this.toDate) ||

        (
          this.fromDate &&
          this.toDate &&
          alert.date >= this.fromDate &&
          alert.date <= this.toDate
        );

      return (
        severityMatch &&
        machineMatch &&
        statusMatch &&
        dateMatch
      );

    });
  }

  // ================= ROLE ACCESS =================

  canAcknowledge() {

    return (
      this.role === 'Maintenance' ||
      this.role === 'Admin'
    );
  }

  // ================= ACKNOWLEDGE ALERT =================

  acknowledge(alert: any) {

    const token = localStorage.getItem('token');

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.put(
      `http://localhost:5028/api/Alerts/${alert.id}/ack`,
      {},
      { headers }
    ).subscribe({

      next: () => {

        alert.acknowledged = true;
        alert.status = 'Closed';

      },

      error: (err) => {
        console.error('Error acknowledging alert', err);
      }

    });
  }

  // ================= CLEAR FILTERS =================

  clearFilters() {

    this.severityFilter = 'All';
    this.machineFilter = 'All';
    this.statusFilter = 'All';

    this.fromDate = '';
    this.toDate = '';
  }

}