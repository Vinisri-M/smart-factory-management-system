import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [NgFor, NgIf, FormsModule],
  templateUrl: './employees.html',
  styleUrl: './employees.css',
})
export class Employees implements OnInit {

  searchText = '';
  roleFilter = 'All';

  employees: any[] = [];

  selectedEmployee: any = null;

  editEmployee: any = {
    hoursWorked: 0,
    leaveDays: 0,
    workedDays: 0
  };

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEmployees();
  }

  getHeaders() {
    const token = localStorage.getItem('token');

    return new HttpHeaders().set(
      'Authorization',
      `Bearer ${token}`
    );
  }

  fetchEmployees() {

    const headers = this.getHeaders();

    this.http.get<any[]>(
      'http://localhost:5028/api/Employees',
      { headers }
    ).subscribe({

      next: (data) => {
        this.employees = data;
        console.log('Employees:', this.employees);
      },

      error: (err) => {
        console.error('Error fetching employees', err);
      }

    });
  }

  get filteredEmployees() {

    return this.employees.filter(emp => {

      const nameMatch = emp.name
        .toLowerCase()
        .includes(this.searchText.toLowerCase());

      const roleMatch =
        this.roleFilter === 'All' ||
        emp.role === this.roleFilter;

      return nameMatch && roleMatch;

    });
  }

  get totalHours() {

    return this.filteredEmployees.reduce(
      (sum, emp) => sum + Number(emp.hoursWorked || 0),
      0
    );
  }

  get totalLeaves() {

    return this.filteredEmployees.reduce(
      (sum, emp) => sum + Number(emp.leaveDays || 0),
      0
    );
  }

  editWork(employee: any) {

    this.selectedEmployee = employee;

    this.editEmployee = {
      hoursWorked: employee.hoursWorked || 0,
      leaveDays: employee.leaveDays || 0,
      workedDays: employee.workedDays || 0
    };
  }

  saveWorkDetails() {

    if (!this.selectedEmployee) {
      return;
    }

    const headers = this.getHeaders();

    const updatedEmployee = {
      ...this.selectedEmployee,
      hoursWorked: Number(this.editEmployee.hoursWorked),
      leaveDays: Number(this.editEmployee.leaveDays),
      workedDays: Number(this.editEmployee.workedDays)
    };

    this.http.put(
      `http://localhost:5028/api/Employees/${this.selectedEmployee.id}`,
      updatedEmployee,
      { headers }
    ).subscribe({

      next: () => {
        this.fetchEmployees();
        this.selectedEmployee = null;
      },

      error: (err) => {
        console.error('Error updating employee', err);
        alert('Failed to update employee');
      }

    });
  }

  cancelEdit() {
    this.selectedEmployee = null;
  }

  resetData() {
    this.fetchEmployees();
  }

}