import { Component, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgIf } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
 standalone: true,
  imports: [FormsModule, NgIf],
  templateUrl: './login.html',
  styleUrl: './login.css'
})

export class Login {

  username = '';
  password = '';

  loginError = '';

  constructor(
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {}

  login() {

    this.loginError = '';

    this.http.post<any>(
      'http://localhost:5028/api/Auth/login',
      {
        email: this.username,
        password: this.password
      }
    ).subscribe({

      next: (res) => {

        if (res && res.token) {

          localStorage.setItem('token', res.token);
          localStorage.setItem('username', res.username);
          localStorage.setItem('role', res.role);

          this.router.navigate(['/dashboard']);

        } else {

          this.loginError = 'Invalid username or password';

          this.cdr.detectChanges();
        }
      },

      error: (err) => {

        console.log(err);

        this.loginError = 'Invalid username or password';

        this.cdr.detectChanges();
      }

    });
  }
}