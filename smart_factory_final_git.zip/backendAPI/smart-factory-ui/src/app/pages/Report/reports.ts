import { Component, OnInit } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BaseChartDirective } from 'ng2-charts';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [NgFor, NgIf, FormsModule, BaseChartDirective],
  templateUrl: './reports.html',
  styleUrl: './reports.css',
})
export class Reports implements OnInit {

  activeTab = 'downtime';

  constructor(private http: HttpClient) {}

  // =====================================================
  // 🔥 DOWNTIME
  // =====================================================

  fromDate = '';
  toDate = '';
  
  machineFilter = 'All';
   machines = [
  'All',
  'Milling Machine B2',
  'Inspection Conveyor H8',
  'Cooling System O15',
  'Palletizer V22'
];

  // 🔥 DATE ERROR
  dateError = '';

  downtimeList: any[] = [];

  barType: any = 'bar';

  downtimeChartData: any = {
    labels: [],
    datasets: []
  };

  // 🔥 DATE VALIDATION

  validateDates(): boolean {

    this.dateError = '';

    if (
      (this.fromDate && !this.toDate) ||
      (!this.fromDate && this.toDate)
    ) {

      this.dateError =
        'Please select both From Date and To Date';

      return false;
    }

    if (
      this.fromDate &&
      this.toDate &&
      this.fromDate > this.toDate
    ) {

      this.dateError =
        'From Date cannot be greater than To Date';

      return false;
    }

    return true;
  }

  get filteredDowntime() {

    // 🔥 DATE SELECT PANNA THA GRAPH
    if (!this.fromDate || !this.toDate) {
      return [];
    }

    return this.downtimeList.filter(item =>

      (
        this.machineFilter === 'All' ||
        item.machine === this.machineFilter
      )

      &&

      (
        item.date >= this.fromDate &&
        item.date <= this.toDate
      )
    );
  }

  convertToHours(duration: string): number {

    if (duration.includes('hour')) {
      return parseFloat(duration);
    }

    if (duration.includes('minutes')) {
      return +(
        parseFloat(duration) / 60
      ).toFixed(2);
    }

    return 0;
  }

  updateChart() {

    const data = this.filteredDowntime;

    if (data.length === 0) {

      this.downtimeChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.downtimeChartData = {

      labels: data.map(d => d.machine),

      datasets: [
        {
          label: 'Downtime',

          data: data.map(d =>
            this.convertToHours(d.duration)
          ),

          backgroundColor: '#1976d2'
        }
      ]
    };
  }

  onFilterChange() {

    // 🔥 VALIDATION
    if (!this.validateDates()) {

      this.downtimeChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    // 🔥 DATE EMPTY
    if (!this.fromDate || !this.toDate) {

      this.downtimeChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.updateChart();
  }

  exportCSV() {

    let csv = 'Machine,Date,Duration\n';

    this.filteredDowntime.forEach(d => {

      csv += `${d.machine},${d.date},${d.duration}\n`;

    });

    const blob = new Blob(
      [csv],
      { type: 'text/csv' }
    );

    const a = document.createElement('a');

    a.href = URL.createObjectURL(blob);

    a.download = 'downtime.csv';

    a.click();
  }

  printReport() {
    window.print();
  }

  // =====================================================
  // 🔥 FAULT
  // =====================================================

  faultFromDate = '';
  faultToDate = '';

  faultMachine = 'All';

  // 🔥 DATE ERROR
  faultDateError = '';

  faults: any[] = [];

  faultMachines = [
    'All',
    'Milling Machine B2',
'Robotic Arm C3',
'Conveyor Belt D4',
'Press Machine E5',
'Welding Station F6',
'Painting Booth G7',
'Inspection Conveyor H8',
'Packaging Unit I9',
'Laser Cutter J10',
'Assembly Robot K11',
'Conveyor Lift L12',
'Mixing Tank M13',
'Drill Press N14',
'Cooling System O15',
'Power Distribution P16',
'Packaging Robot Q17',
'Forklift R18',
'Extruder S19',
'Compressor T20',
'Quality Scanner U21',
'Palletizer V22',
'Heat Exchanger W23',
'Robotic Picker X24'
  ];

  pieType: any = 'pie';
  lineType: any = 'line';

  faultChartData: any = {
    labels: [],
    datasets: []
  };

  faultTrendData: any = {
    labels: [],
    datasets: []
  };

  // 🔥 DATE VALIDATION

  validateFaultDates(): boolean {

    this.faultDateError = '';

    if (
      (this.faultFromDate && !this.faultToDate)
      ||
      (!this.faultFromDate && this.faultToDate)
    ) {

      this.faultDateError =
        'Please select both From Date and To Date';

      return false;
    }

    if (
      this.faultFromDate &&
      this.faultToDate &&
      this.faultFromDate > this.faultToDate
    ) {

      this.faultDateError =
        'From Date cannot be greater than To Date';

      return false;
    }

    return true;
  }

  get filteredFaults() {

    // 🔥 DATE SELECT PANNA THA GRAPH
    if (
      !this.faultFromDate ||
      !this.faultToDate
    ) {
      return [];
    }

    return this.faults.filter(f =>

      (
        this.faultMachine === 'All'
        ||
        f.machine === this.faultMachine
      )

      &&

      (
        f.date >= this.faultFromDate
        &&
        f.date <= this.faultToDate
      )
    );
  }

  updateFaultChart() {

    const data = this.filteredFaults;

    if (data.length === 0) {

      this.faultChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.faultChartData = {

      labels: ['High', 'Medium', 'Low'],

      datasets: [
        {
          data: [

            data.filter(
              f => f.severity === 'High'
            ).length,

            data.filter(
              f => f.severity === 'Medium'
            ).length,

            data.filter(
              f => f.severity === 'Low'
            ).length
          ],

          backgroundColor: [
            'red',
            'orange',
            'green'
          ]
        }
      ]
    };
  }

  updateFaultTrend() {

    const data = this.filteredFaults;

    if (data.length === 0) {

      this.faultTrendData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.faultTrendData = {

      labels: data.map(
        (_, i) => `Day ${i + 1}`
      ),

      datasets: [
        {
          label: 'Trend',

          data: data.map(f =>

            f.severity === 'High'
              ? 3
              : f.severity === 'Medium'
              ? 2
              : 1
          ),

          borderColor: '#1976d2'
        }
      ]
    };
  }

  onFaultFilterChange() {

    // 🔥 VALIDATION
    if (!this.validateFaultDates()) {

      this.faultChartData = {
        labels: [],
        datasets: []
      };

      this.faultTrendData = {
        labels: [],
        datasets: []
      };

      return;
    }

    // 🔥 DATE EMPTY
    if (
      !this.faultFromDate ||
      !this.faultToDate
    ) {

      this.faultChartData = {
        labels: [],
        datasets: []
      };

      this.faultTrendData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.updateFaultChart();

    this.updateFaultTrend();
  }

  // =====================================================
  // 🔥 PERFORMANCE
  // =====================================================


  selectedMachine = 'All';

  perfFromDate = '';
  perfToDate = '';

  // 🔥 DATE ERROR
  performanceDateError = '';
  machineNames = [
    'All',
  'Milling Machine B2',
  'Robotic Arm C3',
  'Conveyor Belt D4',
  'Press Machine E5',
  'Welding Station F6',
  'Painting Booth G7',
  'Inspection Conveyor H8',
  'Packaging Unit I9',
  'Laser Cutter J10',
  'Assembly Robot K11',
  'Conveyor Lift L12',
  'Mixing Tank M13',
  'Drill Press N14',
  'Cooling System O15',
  'Power Distribution P16',
  'Packaging Robot Q17',
  'Forklift R18',
  'Extruder S19',
  'Compressor T20',
  'Quality Scanner U21',
  'Palletizer V22',
  'Heat Exchanger W23',
  'Robotic Picker X24'
];

  performanceData: any[] = [];

  performanceChartData: any = {
    labels: [],
    datasets: []
  };

  lineType1: any = 'line';

  // 🔥 DATE VALIDATION

  validatePerformanceDates(): boolean {

    this.performanceDateError = '';

    if (
      (this.perfFromDate && !this.perfToDate)
      ||
      (!this.perfFromDate && this.perfToDate)
    ) {

      this.performanceDateError =
        'Please select both From Date and To Date';

      return false;
    }

    if (
      this.perfFromDate &&
      this.perfToDate &&
      this.perfFromDate > this.perfToDate
    ) {

      this.performanceDateError =
        'From Date cannot be greater than To Date';

      return false;
    }

    return true;
  }

  get filteredPerformance() {

    // 🔥 DATE SELECT PANNA THA GRAPH
    if (
      !this.perfFromDate ||
      !this.perfToDate
    ) {
      return [];
    }

    return this.performanceData.filter(d => {

      const itemDate = new Date(d.date);

      const from =
        this.perfFromDate
          ? new Date(this.perfFromDate)
          : null;

      const to =
        this.perfToDate
          ? new Date(this.perfToDate)
          : null;

      return (

        (
          this.selectedMachine === 'All'
          ||
          d.machine === this.selectedMachine
        )

        &&

        (!from || itemDate >= from)

        &&

        (!to || itemDate <= to)
      );
    });
  }

  filterPerformanceChart() {

    const data = this.filteredPerformance;

    if (data.length === 0) {

      this.performanceChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    const dates = [
      ...new Set(
        data.map(d => d.date)
      )
    ];

    const machines =

      this.selectedMachine === 'All'

      ?

      [...new Set(
        data.map(d => d.machine)
      )]

      :

      [this.selectedMachine];

    const datasets = machines.map((machine) => ({

      label: machine,

      data: dates.map(date => {

        const found = data.find(d =>

          d.machine === machine &&
          d.date === date

        );

        return found
          ? found.temp
          : null;
      }),

      fill: false
    }));

    this.performanceChartData = {
      labels: dates,
      datasets: datasets
    };
  }

  get avgTemp() {

    if (
      this.filteredPerformance.length === 0
    ) {
      return 0;
    }

    const total =

      this.filteredPerformance.reduce(
        (sum, d) => sum + d.temp,
        0
      );

    return Math.round(
      total /this.filteredPerformance.length
    );
  }

  get uptime() {

    if (
      this.filteredPerformance.length === 0
    ) {
      return 0;
    }

    const onlineMachines =

      this.filteredPerformance.filter(
        d => d.temp > 0
      ).length;

    return Math.round(

      (
        onlineMachines /
        this.filteredPerformance.length
      ) * 100
    );
  }

  get utilization() {

    if (
      this.filteredPerformance.length === 0
    ) {
      return 0;
    }

    const totalLoad =

      this.filteredPerformance.reduce(
        (sum, d) => sum + d.load,
        0
      );

    return Math.round(
      totalLoad /
      this.filteredPerformance.length
    );
  }

  onPerformanceChange() {

    // 🔥 VALIDATION
    if (!this.validatePerformanceDates()) {

      this.performanceChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    // 🔥 DATE EMPTY
    if (
      !this.perfFromDate ||
      !this.perfToDate
    ) {

      this.performanceChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.filterPerformanceChart();
  }

  // =====================================================
  // 🔥 ALERT
  // =====================================================

  alertStatus = 'All';
  alertRole = 'All';
  
  
  alertFromDate = '';
  alertToDate = '';
  alertMachine= 'All';

alertMachines = [
  'All',
  'Robotic Arm C3',
  'Press Machine E5',
  'Welding Station F6',
  'Packaging Unit I9',
  'Assembly Robot K11',
  'Conveyor Lift L12'
];

  // 🔥 DATE ERROR
  alertDateError = '';

  alertStatuses = [
    'All',
    'Open',
    'Closed'
  ];

  alertRoles = [
    'All',
    'Operator',
    'Supervisor',
    'Maintenance'
  ];

  alerts: any[] = [];

  alertChartData: any = {
    labels: [],
    datasets: []
  };
   

  // 🔥 DATE VALIDATION

  validateAlertDates(): boolean {

    this.alertDateError = '';

    if (
      (this.alertFromDate && !this.alertToDate)
      ||
      (!this.alertFromDate && this.alertToDate)
    ) {

      this.alertDateError =
        'Please select both From Date and To Date';

      return false;
    }

    if (
      this.alertFromDate &&
      this.alertToDate &&
      this.alertFromDate > this.alertToDate
    ) {

      this.alertDateError =
        'From Date cannot be greater than To Date';

      return false;
    }

    return true;
  }

  get filteredAlerts() {

    // 🔥 DATE SELECT PANNA THA GRAPH
    if (
      !this.alertFromDate ||
      !this.alertToDate
    ) {
      return [];
    }

    return this.alerts.filter(a => {

      const statusMatch =
        this.alertStatus === 'All' ||
        a.status === this.alertStatus;

      const roleMatch =
        this.alertRole === 'All' ||
        a.role === this.alertRole;

      const dateMatch =

        a.date >= this.alertFromDate

        &&

        a.date <= this.alertToDate;

      return (
        statusMatch &&
        roleMatch &&
        dateMatch
      );
    });
  }

  updateAlertChart() {

    const data = this.filteredAlerts;

    if (data.length === 0) {

      this.alertChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    const openCount =
      data.filter(
        a => a.status === 'Open'
      ).length;

    const closedCount =
      data.filter(
        a => a.status === 'Closed'
      ).length;

    this.alertChartData = {

      labels: ['Alerts'],

      datasets: [
        {
          label: 'Open',

          data: [openCount],

          backgroundColor: 'red'
        },

        {
          label: 'Closed',

          data: [closedCount],

          backgroundColor: 'green'
        }
      ]
    };
  }

  acknowledge(a: any) {

    a.status = 'Closed';

    this.updateAlertChart();
  }

  onAlertChange() {

    // 🔥 VALIDATION
    if (!this.validateAlertDates()) {

      this.alertChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    // 🔥 DATE EMPTY
    if (
      !this.alertFromDate ||
      !this.alertToDate
    ) {

      this.alertChartData = {
        labels: [],
        datasets: []
      };

      return;
    }

    this.updateAlertChart();
  }

  // =====================================================
  // 🔥 INIT
  // =====================================================

  ngOnInit() {

    const token = localStorage.getItem('token');

    const headers = new HttpHeaders().set(
      'Authorization',
      `Bearer ${token}`
    );

    // 🔥 DOWNTIME API

    this.http.get<any[]>(
      'http://localhost:5028/api/Downtime',
      { headers }
    ).subscribe({

      next: (data) => {

        this.downtimeList = data;

        this.downtimeChartData = {
          labels: [],
          datasets: []
        };
      }
    });

    // 🔥 ALERTS API

    this.http.get<any[]>(
      'http://localhost:5028/api/Alerts',
      { headers }
    ).subscribe({

      next: (data) => {

        this.faults = data;

        this.alerts = data.map(a => ({
          ...a,
          role: a.role || 'Operator',
          response: a.response || 5
        }));

        this.faultChartData = {
          labels: [],
          datasets: []
        };

        this.faultTrendData = {
          labels: [],
          datasets: []
        };

        this.alertChartData = {
          labels: [],
          datasets: []
        };
      }
    });

    // 🔥 PERFORMANCE API

    this.http.get<any[]>(
      'http://localhost:5028/api/Machine/dashboard',
      { headers }
    ).subscribe({

      next: (data) => {

        this.performanceData = data.map(m => ({
          machine: m.name,
          date: new Date().toISOString().split('T')[0],
          temp: m.temperature,
          load: m.load
        }));

        this.performanceChartData = {
          labels: [],
          datasets: []
        };
      }
    });
  }
}