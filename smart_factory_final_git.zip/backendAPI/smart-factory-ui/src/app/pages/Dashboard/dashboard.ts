import { Component, OnInit } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, FormsModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit {
  role = localStorage.getItem('role');
  username = localStorage.getItem('username') || 'User';
  searchText = '';
  selectedMachine: any = null;
  user = {
    name: this.username,
    role: this.role
  };

  menuOpen = false;
  machines: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchMachines();
  }

  getHeaders() {
    const token = localStorage.getItem('token');
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  fetchMachines() {
    this.http.get<any[]>('http://localhost:5028/api/Machine/dashboard', { headers: this.getHeaders() })
      .subscribe({
        next: (data) => this.machines = data,
        error: (err) => console.error('Failed to fetch machines', err)
      });
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  get normalCount() {
    return this.machines.filter(m => m.status === 'Normal').length;
  }

  get alertCount() {
    return this.machines.filter(m => m.status === 'Alert').length;
  }

  get offlineCount() {
    return this.machines.filter(m => m.status === 'Offline').length;
  }

  get filteredMachines() {
    return this.machines.filter(machine =>
      machine.name.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  canViewDetails(machine?: any) {
    if (this.role === 'Admin' || this.role === 'Supervisor') {
      return true;
    }

    if (this.role === 'Maintenance' && machine) {
      return machine.status === 'Alert' || machine.status === 'Offline';
    }

    return false;
  }

  viewDetails(machine: any) {
    if (this.canViewDetails(machine)) {
      this.selectedMachine = machine;
    }
  }

  closeDetails() {
    this.selectedMachine = null;
  }
}