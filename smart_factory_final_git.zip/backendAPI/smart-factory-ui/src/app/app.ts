import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, Router, RouterLinkActive } from '@angular/router';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, NgIf],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  constructor(public router: Router) {}

  // 🔐 Check login page (hide sidebar on login)
  isLoginPage() {
    return this.router.url === '/';
  }

  // 👤 Get role from localStorage
  get role() {
    return localStorage.getItem('role');
  }

  // 👥 Role checks
  isAdmin() {
    return this.role === 'Admin';
  }

  isSupervisor() {
    return this.role === 'Supervisor';
  }

  isOperator() {
    return this.role === 'Operator';
  }

  isMaintenance() {
    return this.role === 'Maintenance';
  }

  // 🚪 Logout function
  logout() {
    localStorage.clear();
    this.router.navigate(['/']);
  }
}