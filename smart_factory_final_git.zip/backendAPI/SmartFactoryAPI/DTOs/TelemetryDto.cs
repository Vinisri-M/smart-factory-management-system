namespace SmartFactoryAPI.DTOs
{
    public class TelemetryDto
    {
        public int MachineId { get; set; }

        public double Temperature { get; set; }

        public double Load { get; set; }
    }
}