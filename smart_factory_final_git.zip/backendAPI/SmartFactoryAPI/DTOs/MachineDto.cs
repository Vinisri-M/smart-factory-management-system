namespace SmartFactoryAPI.DTOs
{
    public class MachineDto
    {
        public string Name { get; set; }

        public string Plant { get; set; }

        public string Section { get; set; }

        public string Status { get; set; }
    }
}