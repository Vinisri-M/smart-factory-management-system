namespace SmartFactoryAPI.DTOs
{
    public class AlertDto
    {
        public int MachineId { get; set; }

        public string Severity { get; set; } // LOW / MEDIUM / HIGH

        public string Message { get; set; }
    }
}