using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using SmartFactoryAPI.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace SmartFactoryAPI.Middleware
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _config;

        public JwtMiddleware(RequestDelegate next, IConfiguration config)
        {
            _next = next;
            _config = config;
        }

        public async Task Invoke(HttpContext context, AppDbContext db)
        {
            var token = context.Request.Headers["Authorization"]
                .FirstOrDefault()?.Split(" ").Last();

            if (token != null)
                AttachUserToContext(context, db, token);

            await _next(context);
        }

        private void AttachUserToContext(HttpContext context, AppDbContext db, string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_config["Jwt:Key"]);

                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var userId = int.Parse(jwtToken.Claims.First(x => x.Type == "id").Value);

                var user = db.Users.FirstOrDefault(x => x.Id == userId);

                if (user != null)
                    context.Items["User"] = user;
            }
            catch
            {
                // invalid token → ignore
            }
        }
    }
}