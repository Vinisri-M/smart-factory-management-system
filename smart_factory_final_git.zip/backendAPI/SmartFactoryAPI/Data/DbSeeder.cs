using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Helpers;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Data
{
    public static class DbSeeder
    {
        public static void Seed(AppDbContext context)
        {
            context.Database.Migrate();

            // 1. Roles
            if (!context.Roles.Any())
            {
                context.Roles.AddRange(
                    new Role { Name = "Admin" },
                    new Role { Name = "Supervisor" },
                    new Role { Name = "Operator" },
                    new Role { Name = "Maintenance" }
                );
                context.SaveChanges();
            }

            // 2. Users (Employees)
            if (!context.Users.Any())
            {
                var adminRole = context.Roles.FirstOrDefault(r => r.Name == "Admin")?.Id ?? 1;
                var supervisorRole = context.Roles.FirstOrDefault(r => r.Name == "Supervisor")?.Id ?? 2;
                var operatorRole = context.Roles.FirstOrDefault(r => r.Name == "Operator")?.Id ?? 3;
                var maintenanceRole = context.Roles.FirstOrDefault(r => r.Name == "Maintenance")?.Id ?? 4;

                context.Users.AddRange(
                    new User { Username = "ADM001", Name = "Viji", Email = "viji@smartfactory.com", PasswordHash = PasswordHasher.Hash("Admin@123"), RoleId = adminRole, IsActive = true, HoursWorked = 160, LeaveDays = 5, WorkedDays = 20, CreatedAt = DateTime.UtcNow },
                    new User { Username = "SUP101", Name = "Srinithi", Email = "srinithi@smartfactory.com", PasswordHash = PasswordHasher.Hash("Supervisor@123"), RoleId = supervisorRole, IsActive = true, HoursWorked = 168, LeaveDays = 2, WorkedDays = 21, CreatedAt = DateTime.UtcNow.AddDays(-30) },
                    new User { Username = "OPR201", Name = "Archana", Email = "archana@smartfactory.com", PasswordHash = PasswordHasher.Hash("Operator@123"), RoleId = operatorRole, IsActive = true, HoursWorked = 160, LeaveDays = 5, WorkedDays = 20, CreatedAt = DateTime.UtcNow.AddDays(-20) },
                    new User { Username = "MNT301", Name = "Srikanth", Email = "srikanth@smartfactory.com", PasswordHash = PasswordHasher.Hash("Maintenance@123"), RoleId = maintenanceRole, IsActive = false, HoursWorked = 160, LeaveDays = 5, WorkedDays = 20, CreatedAt = DateTime.UtcNow.AddDays(-15) },
                    new User { Username = "OPR202", Name = "Vinisri", Email = "vinisri@smartfactory.com", PasswordHash = PasswordHasher.Hash("Operator@123"), RoleId = operatorRole, IsActive = true, HoursWorked = 180, LeaveDays = 1, WorkedDays = 22, CreatedAt = DateTime.UtcNow.AddDays(-15) }
                );
                context.SaveChanges();
            }

            // 3. Machines
            if (!context.Machines.Any())
            {
                context.Machines.AddRange(
                    new Machine { Name = "CNC Lathe A1", Plant = "Plant North", Section = "Machining", Status = "RUNNING", CreatedAt = DateTime.UtcNow },
                    new Machine { Name = "Milling Machine B2", Plant = "Plant North", Section = "Machining", Status = "DOWN", CreatedAt = DateTime.UtcNow },
                    new Machine { Name = "Robotic Arm C3", Plant = "Plant South", Section = "Assembly", Status = "RUNNING", CreatedAt = DateTime.UtcNow },
                    new Machine { Name = "Conveyor Belt D4", Plant = "Plant South", Section = "Logistics", Status = "RUNNING", CreatedAt = DateTime.UtcNow },
                    new Machine { Name = "Press Machine E5", Plant = "Plant East", Section = "Fabrication", Status = "MAINTENANCE", CreatedAt = DateTime.UtcNow.AddMinutes(-5) },
                    new Machine { Name = "Welding Station F6", Plant = "Plant East", Section = "Assembly", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-10) },
                    new Machine { Name = "Painting Booth G7", Plant = "Plant West", Section = "Finishing", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-15) },
                    new Machine { Name = "Inspection Conveyor H8", Plant = "Plant West", Section = "Quality", Status = "DOWN", CreatedAt = DateTime.UtcNow.AddMinutes(-20) },
                    new Machine { Name = "Packaging Unit I9", Plant = "Plant North", Section = "Logistics", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-25) },
                    new Machine { Name = "Laser Cutter J10", Plant = "Plant South", Section = "Fabrication", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-30) },
                    new Machine { Name = "Assembly Robot K11", Plant = "Plant East", Section = "Assembly", Status = "MAINTENANCE", CreatedAt = DateTime.UtcNow.AddMinutes(-35) },
                    new Machine { Name = "Conveyor Lift L12", Plant = "Plant West", Section = "Logistics", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-40) },
                    new Machine { Name = "Mixing Tank M13", Plant = "Plant North", Section = "Processing", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-45) },
                    new Machine { Name = "Drill Press N14", Plant = "Plant South", Section = "Machining", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-50) },
                    new Machine { Name = "Cooling System O15", Plant = "Plant East", Section = "Support", Status = "DOWN", CreatedAt = DateTime.UtcNow.AddMinutes(-55) },
                    new Machine { Name = "Power Distribution P16", Plant = "Plant West", Section = "Support", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-60) },
                    new Machine { Name = "Packaging Robot Q17", Plant = "Plant North", Section = "Logistics", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-65) },
                    new Machine { Name = "Forklift R18", Plant = "Plant South", Section = "Logistics", Status = "MAINTENANCE", CreatedAt = DateTime.UtcNow.AddMinutes(-70) },
                    new Machine { Name = "Extruder S19", Plant = "Plant East", Section = "Processing", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-75) },
                    new Machine { Name = "Compressor T20", Plant = "Plant West", Section = "Support", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-80) },
                    new Machine { Name = "Quality Scanner U21", Plant = "Plant North", Section = "Quality", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-85) },
                    new Machine { Name = "Palletizer V22", Plant = "Plant South", Section = "Logistics", Status = "DOWN", CreatedAt = DateTime.UtcNow.AddMinutes(-90) },
                    new Machine { Name = "Heat Exchanger W23", Plant = "Plant East", Section = "Processing", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-95) },
                    new Machine { Name = "Robotic Picker X24", Plant = "Plant West", Section = "Assembly", Status = "RUNNING", CreatedAt = DateTime.UtcNow.AddMinutes(-100) }
                );
                context.SaveChanges();
            }

            // 4. Telemetry
            if (!context.Telemetries.Any())
            {
                var machines = context.Machines.Take(20).ToList();
                var now = DateTime.UtcNow;
                foreach (var machine in machines)
                {
                    context.Telemetries.AddRange(
                        new Telemetry { MachineId = machine.Id, Temperature = 60.0 + machine.Id % 15 + 0.5, Load = 50.0 + machine.Id % 30 + 1.2, Timestamp = now.AddMinutes(-machine.Id * 5) },
                        new Telemetry { MachineId = machine.Id, Temperature = 61.5 + machine.Id % 12 + 0.7, Load = 55.0 + machine.Id % 25 + 1.8, Timestamp = now.AddMinutes(-machine.Id * 3) },
                        new Telemetry { MachineId = machine.Id, Temperature = 62.8 + machine.Id % 10 + 0.3, Load = 58.0 + machine.Id % 20 + 2.0, Timestamp = now.AddMinutes(-machine.Id) }
                    );
                }

                context.Telemetries.AddRange(
                    new Telemetry { MachineId = machines[0].Id, Temperature = 70.2, Load = 85.3, Timestamp = now.AddMinutes(-2) },
                    new Telemetry { MachineId = machines[1].Id, Temperature = 45.9, Load = 41.7, Timestamp = now.AddMinutes(-4) }
                );
                context.SaveChanges();
            }

            // 5. Alerts
            if (!context.Alerts.Any())
            {
                var machines = context.Machines.Take(12).ToList();
                var now = DateTime.UtcNow;
                var alertData = new[]
                {
                    ("Telemetry", "Telemetry spike detected on machine", "High"),
                    ("Power Issue", "Power supply instability detected", "Critical"),
                    ("Maintenance", "Preventive maintenance due soon", "Medium"),
                    ("Network Issue", "Network latency affecting sensors", "Low")
                };

                for (int i = 0; i < 24; i++)
                {
                    var machine = machines[i % machines.Count];
                    var category = alertData[i % alertData.Length];
                    context.Alerts.Add(new Alert
                    {
                        MachineId = machine.Id,
                        Severity = category.Item3,
                        Message = category.Item2,
                        IsAcknowledged = i % 3 == 0,
                        CreatedAt = now.AddMinutes(-i * 10)
                    });
                }

                context.SaveChanges();
            }

            // 6. Downtimes
            if (!context.Downtimes.Any())
            {
                var machines = context.Machines.Take(12).ToList();
                var now = DateTime.UtcNow;
                var downtimeReasons = new[]
                {
                    "Telemetry anomaly",
                    "Power Issue",
                    "Maintenance work",
                    "Network Issue"
                };

                for (int i = 0; i < 24; i++)
                {
                    var machine = machines[i % machines.Count];
                    var reason = downtimeReasons[i % downtimeReasons.Length];
                    var start = now.AddHours(-((i + 1) * 2));
                    var end = i % 4 == 0 ? (DateTime?)null : start.AddHours(1 + i % 3);

                    context.Downtimes.Add(new Downtime
                    {
                        MachineId = machine.Id,
                        StartTime = start,
                        EndTime = end,
                        Reason = reason
                    });
                }

                context.SaveChanges();
            }
        }
    }
}