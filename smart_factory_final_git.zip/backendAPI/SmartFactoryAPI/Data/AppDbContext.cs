using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // 🔐 Auth Tables
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }

        // 🏭 Core System Tables
        public DbSet<Machine> Machines { get; set; }
        public DbSet<Telemetry> Telemetries { get; set; }
        public DbSet<Alert> Alerts { get; set; }
        public DbSet<Downtime> Downtimes { get; set; }

        // 📊 Extra Tables (from your assignment)
        public DbSet<AlertAcknowledgement> AlertAcknowledgements { get; set; }
        public DbSet<LoginAudit> LoginAudits { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ✅ Role Name Unique
            modelBuilder.Entity<Role>()
                .HasIndex(r => r.Name)
                .IsUnique();

            // ✅ User Email Unique
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // ✅ User → Role (Many-to-One)
            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany(r => r.Users)
                .HasForeignKey(u => u.RoleId)
                .OnDelete(DeleteBehavior.Restrict);

            // ✅ Telemetry → Machine
            modelBuilder.Entity<Telemetry>()
                .HasOne(t => t.Machine)
                .WithMany()
                .HasForeignKey(t => t.MachineId);

            // ✅ Alert → Machine
            modelBuilder.Entity<Alert>()
                .HasOne(a => a.Machine)
                .WithMany()
                .HasForeignKey(a => a.MachineId);

            // ✅ Downtime → Machine
            modelBuilder.Entity<Downtime>()
                .HasOne(d => d.Machine)
                .WithMany()
                .HasForeignKey(d => d.MachineId);

            // ✅ AlertAcknowledgement relationships
            modelBuilder.Entity<AlertAcknowledgement>()
                .HasOne(a => a.Alert)
                .WithMany()
                .HasForeignKey(a => a.AlertId);

            modelBuilder.Entity<AlertAcknowledgement>()
                .HasOne(a => a.User)
                .WithMany()
                .HasForeignKey(a => a.UserId);
        }
    }
}