using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EmployeesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            var users = await _context.Users.Include(u => u.Role).ToListAsync();
            var result = users.Select(u => new {
                id = u.Id,
                name = u.Email, // Using email as name for mapping, matching UsersController
                role = u.Role.Name,
                hoursWorked = u.HoursWorked,
                leaveDays = u.LeaveDays,
                workedDays = u.WorkedDays
            });
            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployee(int id, [FromBody] EmployeeDto dto)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            user.HoursWorked = dto.HoursWorked;
            user.LeaveDays = dto.LeaveDays;
            user.WorkedDays = dto.WorkedDays;

            await _context.SaveChangesAsync();
            return Ok(new {
                id = user.Id,
                name = user.Email,
                role = "Unknown", // Just dummy for response
                hoursWorked = user.HoursWorked,
                leaveDays = user.LeaveDays,
                workedDays = user.WorkedDays
            });
        }
    }

    public class EmployeeDto
    {
        public int HoursWorked { get; set; }
        public int LeaveDays { get; set; }
        public int WorkedDays { get; set; }
    }
}
