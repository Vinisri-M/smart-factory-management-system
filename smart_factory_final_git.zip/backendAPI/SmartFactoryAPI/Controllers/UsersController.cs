using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;
using SmartFactoryAPI.Helpers;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")] 
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> GetUsers()
        {
            var users = await _context.Users.Include(u => u.Role).ToListAsync();
            var audits = await _context.LoginAudits.ToListAsync();

                var result = users.Select(u => {
                    var latestLogin = audits.Where(a => a.UserId == u.Id).OrderByDescending(a => a.LoginTime).FirstOrDefault();
                    return new {
                        id = u.Id,
                        empId = u.Username,
                        name = u.Name,
                        email = u.Email,
                        role = u.Role != null ? u.Role.Name : string.Empty,
                        status = u.IsActive ? "Active" : "Inactive",
                        lastLogin = latestLogin != null ? latestLogin.LoginTime.ToString("hh:mm tt") : "Not logged in"
                    };
                }).ToList();

            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddUser([FromBody] UserDto dto)
        {
            var role = await _context.Roles.FirstOrDefaultAsync(r => r.Name == dto.Role);
            if (role == null) return BadRequest("Invalid role");

            var user = new User
            {
                Username = dto.EmpId,
                Name = dto.Name,
                Email = dto.Name,
                PasswordHash = PasswordHasher.Hash("1234"), // Default password
                RoleId = role.Id,
                IsActive = dto.Status == "Active"
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UserDto dto)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            var role = await _context.Roles.FirstOrDefaultAsync(r => r.Name == dto.Role);
            if (role != null) user.RoleId = role.Id;

            user.Username = dto.EmpId;
            user.Email = dto.Name;
            user.IsActive = dto.Status == "Active";

            await _context.SaveChangesAsync();

            return Ok(user);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return Ok();
        }
    }

    public class UserDto
    {
        public int Id { get; set; }
        public string? EmpId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Role { get; set; }
        public string? Status { get; set; }
    }
}