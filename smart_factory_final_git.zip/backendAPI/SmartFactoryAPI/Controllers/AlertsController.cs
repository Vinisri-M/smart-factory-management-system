using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,Supervisor,Maintenance")]
    public class AlertsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AlertsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAlerts()
        {
            var alerts = await _context.Alerts.Include(a => a.Machine).ToListAsync();
            
            var result = alerts.Select(a => new {
                id = a.Id,
                machine = a.Machine != null ? a.Machine.Name : "Unknown",
                severity = a.Severity,
                message = a.Message,
                time = a.CreatedAt.ToString("HH:mm"),
                date = a.CreatedAt.ToString("yyyy-MM-dd"),
                acknowledged = a.IsAcknowledged,
                status = a.IsAcknowledged ? "Closed" : "Open"
            });

            return Ok(result);
        }

        [HttpPut("{id}/ack")]
        public async Task<IActionResult> Acknowledge(int id)
        {
            var alert = await _context.Alerts.FindAsync(id);
            if (alert == null) return NotFound();

            alert.IsAcknowledged = true;
            await _context.SaveChangesAsync();

            return Ok(alert);
        }
    }
}