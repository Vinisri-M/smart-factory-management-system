using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TelemetryController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TelemetryController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> AddTelemetry(Telemetry telemetry)
        {
            _context.Telemetries.Add(telemetry);
            await _context.SaveChangesAsync();
            return Ok(telemetry);
        }

        [HttpGet("{machineId}")]
        public async Task<IActionResult> GetTelemetry(int machineId)
        {
            var data = await _context.Telemetries
                .Where(t => t.MachineId == machineId)
                .ToListAsync();

            return Ok(data);
        }
    }
}