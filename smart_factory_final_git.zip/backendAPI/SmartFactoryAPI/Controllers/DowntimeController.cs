using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,Supervisor,Maintenance")]
    public class DowntimeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DowntimeController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetDowntime()
        {
            var downtimes = await _context.Downtimes.Include(d => d.Machine).ToListAsync();

            var result = downtimes.Select(d => {
                var durationStr = "Ongoing";
                if (d.EndTime.HasValue)
                {
                    var span = d.EndTime.Value - d.StartTime;
                    durationStr = $"{span.Hours} hours {span.Minutes} minutes".Trim();
                }

                return new {
                    machine = d.Machine != null ? d.Machine.Name : "Unknown",
                    date = d.StartTime.ToString("yyyy-MM-dd"),
                    from = d.StartTime.ToString("HH:mm"),
                    to = d.EndTime.HasValue ? d.EndTime.Value.ToString("HH:mm") : "Ongoing",
                    duration = durationStr,
                    reason = d.Reason
                };
            });

            return Ok(result);
        }
    }
}