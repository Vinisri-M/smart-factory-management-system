using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // any logged-in user can view
    public class MachineController : ControllerBase
    {
        private readonly AppDbContext _context;

        public MachineController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetMachines()
        {
            return Ok(await _context.Machines.ToListAsync());
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> AddMachine(Machine machine)
        {
            _context.Machines.Add(machine);
            await _context.SaveChangesAsync();
            return Ok(machine);
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboardMachines()
        {
            var machines = await _context.Machines.ToListAsync();
            var telemetries = await _context.Telemetries.ToListAsync();
            var alerts = await _context.Alerts.Where(a => !a.IsAcknowledged).ToListAsync();

            var result = machines.Select(m => {
                var machineTelemetries = telemetries.Where(t => t.MachineId == m.Id).ToList();
                var latestTelemetry = machineTelemetries.OrderByDescending(t => t.Timestamp).FirstOrDefault();
                var hasActiveAlert = alerts.Any(a => a.MachineId == m.Id);

                return new 
                {
                    id = m.Id,
                    name = m.Name,
                    temperature = latestTelemetry?.Temperature ?? 0,
                    rpm = 0,
                    load = latestTelemetry?.Load ?? 0,
                    status = m.Status == "DOWN" ? "Offline" : (hasActiveAlert ? "Alert" : "Normal")
                };
            });
            
            return Ok(result);
        }
    }
}