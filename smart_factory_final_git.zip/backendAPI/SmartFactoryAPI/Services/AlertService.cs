using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Services
{
    public class AlertService
    {
        private readonly AppDbContext _context;

        public AlertService(AppDbContext context)
        {
            _context = context;
        }

        public async Task GenerateAlert(int machineId, double temperature)
        {
            string severity = "LOW";

            if (temperature > 80) severity = "HIGH";
            else if (temperature > 60) severity = "MEDIUM";

            var alert = new Alert
            {
                MachineId = machineId,
                Severity = severity,
                Message = $"Temperature is {temperature}"
            };

            _context.Alerts.Add(alert);
            await _context.SaveChangesAsync();
        }
    }
}