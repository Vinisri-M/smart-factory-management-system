using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.DTOs;
using SmartFactoryAPI.Helpers;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Services
{
    public class AuthService
    {
        private readonly AppDbContext _context;
        private readonly TokenService _tokenService;

        public AuthService(AppDbContext context, TokenService tokenService)
        {
            _context = context;
            _tokenService = tokenService;
        }

        public async Task<string> Register(RegisterDto dto)
        {
            var role = await _context.Roles
                .FirstOrDefaultAsync(r => r.Name == dto.Role);

            if (role == null)
                return "Invalid role";

            var user = new User
            {
                Username = dto.Username,
                Email = dto.Email,
                PasswordHash = PasswordHasher.Hash(dto.Password),
                RoleId = role.Id
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return "User registered successfully";
        }

        public async Task<object> Login(LoginDto dto)
        {
            var user = await _context.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Email == dto.Email || u.Username == dto.Email);

            if (user == null || !PasswordHasher.Verify(dto.Password, user.PasswordHash))
                return null;

            var token = _tokenService.GenerateToken(user);

            return new
            {
                token,
                username = user.Username,
                role = user.Role.Name
            };
        }
    }
}