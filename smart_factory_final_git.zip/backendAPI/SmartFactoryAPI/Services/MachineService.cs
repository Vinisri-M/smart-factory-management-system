using Microsoft.EntityFrameworkCore;
using SmartFactoryAPI.Data;
using SmartFactoryAPI.Models;

namespace SmartFactoryAPI.Services
{
    public class MachineService
    {
        private readonly AppDbContext _context;

        public MachineService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Machine>> GetAll()
        {
            return await _context.Machines.ToListAsync();
        }

        public async Task<Machine> Add(Machine machine)
        {
            _context.Machines.Add(machine);
            await _context.SaveChangesAsync();
            return machine;
        }
    }
}