using BCrypt.Net;

namespace SmartFactoryAPI.Helpers
{
    public static class PasswordHasher
    {
        // Hash password
        public static string Hash(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        // Verify password
        public static bool Verify(string password, string hash)
        {
            return BCrypt.Net.BCrypt.Verify(password, hash);
        }
    }
}