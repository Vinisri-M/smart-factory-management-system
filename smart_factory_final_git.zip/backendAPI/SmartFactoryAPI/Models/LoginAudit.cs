using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class LoginAudit
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        public DateTime LoginTime { get; set; } = DateTime.UtcNow;

        public string IpAddress { get; set; }
    }
}