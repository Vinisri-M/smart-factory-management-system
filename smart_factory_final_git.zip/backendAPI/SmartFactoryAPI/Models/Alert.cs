using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class Alert
    {
        [Key]
        public int Id { get; set; }

        public int MachineId { get; set; }

        [ForeignKey("MachineId")]
        public Machine Machine { get; set; }

        public string Severity { get; set; } // LOW / MEDIUM / HIGH

        public string Message { get; set; }

        public bool IsAcknowledged { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}