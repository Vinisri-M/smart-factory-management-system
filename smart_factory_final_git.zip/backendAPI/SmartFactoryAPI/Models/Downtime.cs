using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class Downtime
    {
        [Key]
        public int Id { get; set; }

        public int MachineId { get; set; }

        [ForeignKey("MachineId")]
        public Machine Machine { get; set; }

        public DateTime StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        public string Reason { get; set; } // e.g., No Telemetry
    }
}