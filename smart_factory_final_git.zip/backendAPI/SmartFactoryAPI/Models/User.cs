using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }


        [Required]
        [MaxLength(100)]
        public string? Username { get; set; }


            [Required]
            [MaxLength(100)]
            public string? Name { get; set; }


        [Required]
        [MaxLength(150)]
        public string? Email { get; set; }
        


        [Required]
        public string? PasswordHash { get; set; }

        // Foreign Key
        public int RoleId { get; set; }

        [ForeignKey("RoleId")]

        public Role? Role { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Employee specific fields
        public int HoursWorked { get; set; } = 0;
        public int LeaveDays { get; set; } = 0;
        public int WorkedDays { get; set; } = 0;
    }
}