using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class AlertAcknowledgement
    {
        [Key]
        public int Id { get; set; }

        public int AlertId { get; set; }

        [ForeignKey("AlertId")]
        public Alert Alert { get; set; }

        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        public DateTime AcknowledgedAt { get; set; } = DateTime.UtcNow;
    }
}