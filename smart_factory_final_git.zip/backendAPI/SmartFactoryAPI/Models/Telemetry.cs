using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SmartFactoryAPI.Models
{
    public class Telemetry
    {
        [Key]
        public int Id { get; set; }

        public int MachineId { get; set; }

        [ForeignKey("MachineId")]
        public Machine Machine { get; set; }

        public double Temperature { get; set; }

        public double Load { get; set; }

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}