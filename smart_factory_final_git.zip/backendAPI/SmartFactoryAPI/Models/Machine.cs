using System.ComponentModel.DataAnnotations;

namespace SmartFactoryAPI.Models
{
    public class Machine
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Plant { get; set; }

        public string Section { get; set; }

        public string Status { get; set; } = "RUNNING"; // RUNNING / DOWN

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}