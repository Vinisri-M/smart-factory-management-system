using System.ComponentModel.DataAnnotations;

namespace SmartFactoryAPI.Models
{
    public class Role
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }

        // Navigation property (One Role → Many Users)
        public ICollection<User> Users { get; set; }
    }
}